import React from 'react';
    import { ArrowRight } from 'lucide-react';

    export default function Home() {
      // Function to handle smooth scrolling to contact section
      const scrollToContact = () => {
        const contactSection = document.getElementById('contact');
        if (contactSection) {
          contactSection.scrollIntoView({ behavior: 'smooth' });
        }
      };

      return (
        <div>
          {/* Hero Section with Call to Action */}
          <div className="relative h-[100vh] flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center fade-in">
              <div className="text-center text-white">
                <h1 className="text-4xl sm:text-5xl font-bold mb-4">CURVED CONCRETE</h1>
                <p className="text-lg sm:text-xl mb-8">A multi-functional firm by Kamla Corporation</p>
                <button
                  onClick={scrollToContact}
                  className="inline-flex items-center bg-white text-gray-900 px-6 py-3 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }
