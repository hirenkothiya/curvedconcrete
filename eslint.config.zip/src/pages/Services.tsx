import React from 'react';
    import { Hammer, PaintBucket, Home, Wrench } from 'lucide-react';

    export default function Services() {
      const services = [
        {
          title: 'Architecture Work',
          icon: Home,
          description: 'Professional architectural design and planning services'
        },
        {
          title: 'Construction Work',
          icon: Hammer,
          description: 'Complete construction services from foundation to finish'
        },
        {
          title: 'Interior Work',
          icon: PaintBucket,
          description: 'Stunning interior design and decoration services'
        },
        {
          title: 'Renovation Work',
          icon: Wrench,
          description: 'Expert renovation and remodeling services'
        }
      ];

      const steps = [
        {
          number: '01',
          title: 'Design',
          description: 'Comprehensive planning and design phase'
        },
        {
          number: '02',
          title: 'Execution',
          description: 'Professional implementation of approved plans'
        },
        {
          number: '03',
          title: 'Supervision',
          description: 'Thorough oversight throughout the project'
        }
      ];


      const steps2 = [
        {
         title2: 'We Do',
          description2: 'Our work\'s all about exploring ideas and really testing them out. We find answers to some seriously tough design problems.'
        },
        {
          title2: 'We Create',
          description2: '​We craft healthy, high-performance spaces of all sizes, carefully turning our clients\' dreams into reality and helping them achieve their goals.'
        },
        {
          title2: 'We Uplift',
          description2: 'Design can really change lives, create memories, and build communities.  Our work matters; it adds beauty and joy to the world.'
        }
      ];




      return (
        <div className="bg-white fade-in">
          <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Services</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {services.map((service) => (
                <div key={service.title} className="bg-gray-50 p-6 rounded-lg text-center">
                  <service.icon className="h-12 w-12 mx-auto mb-4 text-gray-800" />
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-gray-600">{service.description}</p>
                </div>
              ))}
            </div>

            <div className="bg-gray-50 p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-8 text-center">Our Process</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {steps.map((step) => (
                  <div key={step.number} className="text-center">
                    <div className="text-4xl font-bold text-gray-300 mb-4">{step.number}</div>
                    <h4 className="text-xl font-semibold mb-2">{step.title}</h4>
                    <p className="text-gray-600">{step.description}</p>
                    
                  </div>
                ))}
              </div>
             
            </div>

            <div className="bg-gray-50 p-8 rounded-lg">
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {steps2.map((step2) => (
                  <div key={step2.title2} className="text-center">
                    <h4 className="text-xl font-semibold mb-2">{step2.title2}</h4>
                    <p className="text-gray-600">{step2.description2}</p>
                    
                  </div>
                ))}
              </div>
            </div>
              
            <div className="mt-16 text-center">
              <h3 className="text-2xl font-bold mb-4">BEGINNING TO END SERVICES FOR A HOUSE</h3>
              <p className="text-gray-600">
                We provide comprehensive solutions for all your construction needs, from initial concept to final completion.
              </p>
            </div>
           
          </div>
        </div>
      );
    }
