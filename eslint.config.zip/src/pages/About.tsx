import React from 'react';

    export default function About() {
      return (
        <div className="bg-white fade-in">
          <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
            <div className="mb-16">
              <h2 className="text-3xl font-bold mb-8">About Us</h2>
              <p className="text-lg text-gray-600 mb-8">
                Since our establishment in 2022, we have successfully completed over 20 projects in the architecture, interior
                design, and construction industry. As a young and dynamic team of experts, we are committed to showcasing our
                potential and expertise in the industry. To this end, we are pleased to offer free consultations to new house,
                flat, or office owners seeking guidance on architecture, interior design, or civil work-related matters.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Our vision is to develop thriving communities that coexist harmoniously with the natural environment, recognizing that the future of our planet depends on this endeavor.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Our operations are research and technology-driven, characterized by curiosity, determination, and innovation. We are committed to daily positive impact, ethical conduct, and continuous improvement.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                In collaboration with our clients, communities, partners, and colleagues, we strive to cultivate a more aesthetically pleasing, sustainable, and equitable global environment. Together, we are designing for a better future.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                We're all ears. Empathy and compassion fuel our commitment to justice, equity, diversity, and inclusion. We live those values daily, in our studios and the communities we work with.
              </p>
            </div>

            <div className="mb-16">
              <h2 className="text-3xl font-bold mb-8">Mission & Vision</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-gray-50 p-6 rounded-lg" style={{ backgroundColor: 'rgba(230, 230, 250, 0.5)' }}>
                  <p className="text-gray-800">
                    Our objective is to deliver superior design, innovative structures, and stunning interiors to a diverse clientele.
                  </p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg" style={{ backgroundColor: 'rgba(230, 230, 250, 0.5)' }}>
                  <p className="text-gray-800">
                    We are developing a technology-driven labor and construction management system to provide clients with real-time project updates.
                  </p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg" style={{ backgroundColor: 'rgba(230, 230, 250, 0.5)' }}>
                  <p className="text-gray-800">
                    Aiming for nationwide deployment across India within the next three years.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }
