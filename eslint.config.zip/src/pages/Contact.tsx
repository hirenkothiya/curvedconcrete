import React, { useState, useRef, useEffect, useCallback } from 'react';
    import { Mail, Phone, Globe, Instagram, MapPin } from 'lucide-react';
    import TestimonialSlider from '../components/TestimonialSlider';

    // Founder's message component
    const FounderMessage = () => {
      const [isOverlayVisible, setIsOverlayVisible] = useState(false);
      const messageBoxRef = useRef<HTMLDivElement>(null);
      const overlayRef = useRef<HTMLDivElement>(null);
      const [overlayWidth, setOverlayWidth] = useState(0);

      useEffect(() => {
        if (messageBoxRef.current) {
          setOverlayWidth(messageBoxRef.current.offsetWidth * 0.95);
        }
      }, []);

      const handleClickOutside = useCallback((event: MouseEvent) => {
        if (overlayRef.current && !overlayRef.current.contains(event.target as Node) &&
            messageBoxRef.current && !messageBoxRef.current.contains(event.target as Node)) {
          setIsOverlayVisible(false);
        }
      }, []);

      useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
          document.removeEventListener('mousedown', handleClickOutside);
        };
      }, [handleClickOutside]);

      const founderDetails = (
        <div
          className="absolute top-full left-0 mt-2 p-6 bg-white border rounded-md shadow-lg z-10"
          style={{
            width: `${overlayWidth}px`,
          }}
          ref={overlayRef}
        >
          <h4 className="text-xl font-semibold mb-4">About Mr. Udit Muni</h4>
          <p className="text-gray-800 mb-4">
            Udit strongly believes that every project should be designed as contextually evolving spaces that are perceived in new ways. Each design takes cognizance of the climate and integrates sustainability in a cohesive way.
          </p>
          <p className="text-gray-800 mb-4">
            Udit Muni started his curriculum in civil engineering with a diploma from the well-known MS University. After successfully completing his diploma, he graduated from Nirma University with a B.Tech in civil engineering in Vadodara in 2021.
          </p>
          <p className="text-gray-800 mb-4">
            He worked with construction and architecture firms throughout his three years of education, from 2019 to 2021. He continued to work there for one year and then started his partnership firm, Living Shades by Udit Muni & Associates. Mr. Udit Muni champions a design philosophy centered on contextually evolving spaces, fostering dynamic user perceptions. Each project prioritizes climate responsiveness and seamlessly integrates sustainable practices.
          </p>
          <p className="text-gray-800 mb-4">
            Mr. Muni's professional journey commenced with a diploma in civil engineering from the esteemed MS University, followed by a B.Tech in civil engineering from Navarachna University, Vadodara, in 2021.
          </p>
          <p className="text-gray-800 mb-4">
            From 2019 to 2022, he gained practical experience through concurrent employment with prominent construction and architectural firms, culminating in the establishment of his partnership firm, Living Shades by Udit Muni & Associates.
          </p>
          <p className="text-gray-800 mb-4">
            Subsequently, he established his own company, Curved Concrete A multi-functional firm by kamla corporation named in honor of his late grandmother, Shri Kamala Muni.
          </p>
          <p className="text-gray-800">
            His career in the industry commenced upon graduation, and he has collaborated with prominent figures on diverse projects spanning architecture, construction, and interior design.
          </p>
        </div>
      );

      return (
        <div className="mb-16 fade-in">
          <h2 className="text-3xl font-bold mb-8">Message from our Founder</h2>
          <div className="bg-gray-50 p-8 rounded-lg" style={{ backgroundColor: 'rgba(230, 230, 250, 0.5)' }} ref={messageBoxRef}>
            <div className="flex items-center mb-6 relative">
              <img
                src="/src/img/portfolio/1736420996992.jpg"
                alt="Mr. UDIT MUNI"
                className="w-24 h-24 rounded-full object-cover mr-6"
                loading="lazy"
              />
              <div>
                <h3 className="text-xl font-bold">
                  <button
                    onClick={() => setIsOverlayVisible(!isOverlayVisible)}
                    className="text-gray-900 hover:underline"
                  >
                    Mr. UDIT MUNI
                  </button>
                </h3>
                <p className="text-gray-600">FOUNDER & MD</p>
              </div>
              {isOverlayVisible && founderDetails}
            </div>
            <div className="text-gray-800 space-y-4">
              <p>
                This firm was founded with a defined objective. Early industry experience revealed a burgeoning niche market
                stemming from the high cost of luxury goods and materials, leading to homeowner confusion regarding optimal choices.
                Moreover, procedural complexities and labor-related issues frequently cause homeowner anxiety concerning the selection
                of a qualified building partner capable of fulfilling their needs and emotional expectations.
              </p>
              <p>
                Indian people are very cultured and rooted; they build homes with emotion. To balance their sentiments with
                practicality, I created this brand for the people of India.
              </p>
            </div>
          </div>
        </div>
      );
    };

    const testimonials = [
      {
        id: 1,
        name: 'Aarav Patel',
        text: 'Curved Concrete transformed our vision into a stunning reality. Their attention to detail and commitment to quality are truly remarkable.',
        image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80'
      },
      {
        id: 2,
        name: 'Priya Sharma',
        text: 'The team at Curved Concrete was incredibly professional and creative. They made the entire process smooth and stress-free, and the results exceeded our expectations.',
        image: 'https://images.unsplash.com/photo-1595152772835-219674b2a8a6?auto=format&fit=crop&q=80'
      },
      {
        id: 3,
        name: 'Rohan Kapoor',
        text: 'From the initial consultation to the final touches, Curved Concrete demonstrated exceptional expertise and dedication. We are thrilled with our new space!',
        image: 'https://images.unsplash.com/photo-1580489944761-15a19d67492d?auto=format&fit=crop&q=80'
      },
      {
        id: 4,
        name: 'Meera Desai',
        text: 'Curved Concrete provided us with innovative solutions and impeccable craftsmanship. Their team was a pleasure to work with, and we highly recommend their services.',
        image: 'https://images.unsplash.com/photo-1580489944761-15a19d67492d?auto=format&fit=crop&q=80'
      }
    ];

    export default function Contact() {
      return (
        <div className="bg-white">
          <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
            {/* Founder's Message Section */}
            <FounderMessage />

            {/* Contact Information Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 fade-in">
              {/* Contact Details */}
              <div>
                <h2 className="text-3xl font-bold mb-8">Get in Touch</h2>
                <div className="space-y-6">
                  <div className="flex items-center">
                    <Mail className="h-6 w-6 text-gray-600 mr-4" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <a href="mailto:Uditmuniinfrawork21@gmail.com" className="text-lg font-medium">
                        Uditmuniinfrawork21@gmail.com
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Globe className="h-6 w-6 text-gray-600 mr-4" />
                    <div>
                      <p className="text-sm text-gray-600">Website</p>
                      <a href="https://CURVEDCONCRETE.COM" className="text-lg font-medium">
                        CURVEDCONCRETE.COM
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-6 w-6 text-gray-600 mr-4" />
                    <div>
                      <p className="text-sm text-gray-600">Phone</p>
                      <a href="tel:95337557444" className="text-lg font-medium">
                        +91 95337557444
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Instagram className="h-6 w-6 text-gray-600 mr-4" />
                    <div>
                      <p className="text-sm text-gray-600">Instagram</p>
                      <a href="https://instagram.com/CURVED_CONCRETE22" className="text-lg font-medium">
                        @CURVED_CONCRETE22
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Testimonial Slider */}
              <div>
                <h3 className="text-2xl font-bold mb-6">What Our Clients Say</h3>
                <TestimonialSlider testimonials={testimonials} />
              </div>
            </div>
          </div>
        </div>
      );
    }
