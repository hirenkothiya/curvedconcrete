import React, { useState, useEffect, useRef } from 'react';
    import { ChevronLeft, ChevronRight } from 'lucide-react';

    interface Testimonial {
      id: number;
      name: string;
      text: string;
      image: string;
    }

    interface TestimonialSliderProps {
      testimonials: Testimonial[];
    }

    export default function TestimonialSlider({ testimonials }: TestimonialSliderProps) {
      const [currentIndex, setCurrentIndex] = useState(0);
      const timerRef = useRef<number | null>(null);

      const nextSlide = () => {
        setCurrentIndex((prev) => (prev + 1) % testimonials.length);
      };

      const prevSlide = () => {
        setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
      };

      useEffect(() => {
        timerRef.current = setInterval(nextSlide, 7000); // Change slide every 7 seconds

        return () => {
          if (timerRef.current) {
            clearInterval(timerRef.current);
          }
        };
      }, [testimonials.length]);

      return (
        <div className="relative group">
          <div className="relative overflow-hidden rounded-lg">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={testimonial.id} className="w-full flex-shrink-0 p-6">
                  <div className="bg-gray-50 p-6 rounded-lg" style={{ backgroundColor: 'rgba(230, 230, 250, 0.5)' }}>
                    <div className="flex items-center mb-4">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full object-cover mr-4"
                        loading="lazy"
                      />
                      <h4 className="text-lg font-semibold">{testimonial.name}</h4>
                    </div>
                    <p className="text-gray-700">{testimonial.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ChevronRight className="h-6 w-6" />
          </button>

          {/* Image Indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>
      );
    }
