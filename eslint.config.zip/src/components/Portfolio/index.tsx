import React, { useState } from 'react';
    import ProjectCard from './ProjectCard';
    import { projects } from './data';

    export default function Portfolio() {
      const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

      const categories = ['All', ...new Set(projects.map(project => project.category))];

      const filteredProjects = selectedCategory && selectedCategory !== 'All'
        ? projects.filter(project => project.category === selectedCategory)
        : projects;

      return (
        <div className="py-16 bg-gray-50 fade-in">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-8">Our Portfolio</h2>

            {/* Category Filter */}
            <div className="flex justify-center space-x-4 mb-12 overflow-x-auto">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full transition-colors whitespace-nowrap ${
                    selectedCategory === category
                      ? 'bg-gray-900 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Projects Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {filteredProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          </div>
        </div>
      );
    }
