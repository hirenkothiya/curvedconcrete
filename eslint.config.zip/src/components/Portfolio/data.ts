export const projects = [
      {
        id: 1,
        title: 'Twin house bungalow',
        category: 'Architecture and Construction Project',
        images: [
          '/src/img/portfolio/AAC1.jpeg',
          '/src/img/portfolio/AAC2.jpeg',
          '/src/img/portfolio/AAC3.jpeg',
          '/src/img/portfolio/AAC4.jpeg',
          '/src/img/portfolio/AAC5.jpeg'
        ],
        description: 'This project encompasses two residences situated on a single lot, featuring separate entrances and ample parking.',
        details: [
          'Design theme: modern contemporary design',
          'Area of the project: 5000 sq ft',
          'Designed by: Curved Concrete',
          'Commencement: february 2024',
          'Current status: in progress with civil work',
          'The homes have distinct, double-story floor plans, with a central elevator serving both.',
          'Key features include four bedrooms and a double-height dining area on the main level.'
        ],
        completion: 'In Progress',
        location: 'Ahmedabad, Gujarat, India'
      },
      {
        id: 2,
        title: 'Project Chitrang',
        category: 'Architecture and Construction Project',
        images: [
          '/src/img/portfolio/AAC6.jpeg',
          '/src/img/portfolio/AAC7.jpeg',
          '/src/img/portfolio/AAC8.jpeg'
        ],
        description: 'A Vastu-Compliant Residence with Unique Architectural Features and Ample Natural Light',
        details: [
          'Designed by: Curved Concrete',
          'Area of the project: 4800 sq ft',
          'Commencement: December 2023',
          'Current stauts: In Progress With Finishing Works',
          'This four-bedroom, four-bathroom residence features varying floor-to-ceiling heights and expansive fixed glazing.',
          'Designed in strict accordance with Vastu principles, the temple\'s placement ensures direct sunlight in the morning.',
          'The home boasts spacious, well-ventilated rooms, and a striking triple-height staircase serves as a central design feature.'
        ],
        completion: 'In Progress',
        location: 'Dakor, Gujarat, India'
      },
      {
        id: 3,
        title: 'Madhav Villa',
        category: 'Interior',
        images: [
          '/src/img/portfolio/INT (1).jpeg',
          '/src/img/portfolio/INT (2).jpeg',
          '/src/img/portfolio/INT (3).jpeg',
          '/src/img/portfolio/INT (4).jpeg',
          '/src/img/portfolio/INT (5).jpeg',
          '/src/img/portfolio/INT (6).jpeg',
          '/src/img/portfolio/INT (7).jpeg',
          '/src/img/portfolio/INT (8).jpeg'
        ],
        description: 'A 3-BHK sample house showcasing a harmonious blend of contemporary and bohemian design elements.',
        details: [
          'Design theme: mix of contemporary and bohemian',
          'Carpet area: 1200 sq ft',
          'Designed & executed by: team curved concrete',
          'This bungalow features a designer foyer upon entry.',
          'The living room is serenely designed with a minimalist pastel aesthetic.',
          'An elegant partition separates the living and kitchen areas.',
          'Bedrooms each possess a distinct atmosphere: the master bedroom showcases a blue theme, the children\'s bedroom a vibrant color scheme with curved furnishings, and the guest bedroom a contemporary design maximizing furniture.',
          'The home\'s design thoughtfully integrates diverse thematic elements.'
        ],
        completion: 'Completed',
        location: 'Anand, Gujarat, India'
      },
      {
        id: 4,
        title: 'Interior Project at Sama',
        category: 'Interior',
        images: [
          '/src/img/portfolio/INTA (1).jpeg',
          '/src/img/portfolio/INTA (2).jpeg',
          '/src/img/portfolio/INTA (3).jpeg',
          '/src/img/portfolio/INTA (4).jpeg'
        ],
        description: 'A modern laminated interior project featuring a beautifully designed living room, kitchen, and master bedroom.',
        details: [
          'Design theme: modern laminated',
          'Carpet area: 3000 sq ft',
          'Designed & executed by: Team Curved Concrete',
          'The project encompasses a beautifully designed living room, kitchen, and master bedroom.',
          'The master bedroom features wood and artistic laminates.',
          'The temple area is designed in cream tones to foster a peaceful atmosphere.',
          'The kitchen prioritizes practicality, maximizing furniture inclusion, such as service platforms with full drawers and upper shutters.'
        ],
        completion: 'Completed',
        location: 'Vadodara, Gujarat, India'
      },
      {
        id: 5,
        title: 'Renovation Project at Vadodara',
        category: 'Renovation',
        images: [
          '/src/img/portfolio/RK (1).jpeg',
          '/src/img/portfolio/RK (2).jpeg',
          '/src/img/portfolio/RK (3).jpeg',
          '/src/img/portfolio/RK (4).jpeg',
          '/src/img/portfolio/RK (5).jpeg',
          '/src/img/portfolio/RK (6).jpeg',
          '/src/img/portfolio/RK (7).jpeg'
        ],
        description: 'A maximalist living room and kitchen renovation featuring a luxurious, grooved aesthetic.',
        details: [
          'Design theme: Aesthetic Grooving',
          'Carpet are: 300 sqft',
          'Designed & executed by: Team Curved Concrete',
          'We\'re doing a living room and kitchen makeover for Darshan and Mansi Patel, our founder\'s bestie!',
          'They\'re stoked for a modern, luxurious look. We\'re going all out with a maximalist design.',
          'Their living room\'s only 15x10 feet and needs to fit dining, a TV, seating, and everything else.',
          'The dining area will utilize a wall-mounted design to maximize spatial efficiency, incorporating a grooved design that integrates seamlessly with the existing wall structure.',
          'The kitchen, compact yet functional for daily needs, features a beige acrylic-glass design.',
          'All walls feature paneled designs, creating a luxurious, grooved aesthetic.'
        ],
        completion: 'Completed',
        location: 'Vadodara, Gujarat, India'
      },
      {
        id: 6,
        title: 'Commercial Office Project',
        category: 'Interior',
        images: [
          '/src/img/portfolio/CO1.jpeg',
          '/src/img/portfolio/CO2.jpeg',
          '/src/img/portfolio/CO3.jpeg'
        ],
        description: 'A commercial office interior project.',
        details: [],
        completion: 'Completed',
        location: 'Vadodara, Gujarat, India'
      },
      {
        id: 7,
        title: 'Conceptual living room makeover for mr. Vimal shah',
        category: 'Other projects',
        images: [
          '/src/img/portfolio/VS1.jpeg',
          '/src/img/portfolio/VS2.jpeg',
          '/src/img/portfolio/VS3.jpeg'
        ],
        description: 'A conceptual living room makeover.',
        details: [],
        completion: 'Conceptual',
        location: 'Vadodara, Gujarat, India'
      },
    ];
