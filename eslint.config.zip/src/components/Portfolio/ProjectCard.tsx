import React, { useState } from 'react';
    import ProjectSlider from './ProjectSlider';
    import { ChevronDown, ChevronUp } from 'lucide-react';

    interface ProjectCardProps {
      project: {
        id: number;
        title: string;
        category: string;
        images: string[];
        description: string;
        details: string[];
        completion: string;
        location: string;
      };
    }

    export default function ProjectCard({ project }: ProjectCardProps) {
      const [isExpanded, setIsExpanded] = useState(false);
      const titleWithLocation = `${project.title} - ${project.location.split(',')[0]}`;

      return (
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <ProjectSlider images={project.images} title={project.title} />
          
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-2xl font-bold mb-2">{titleWithLocation}</h3>
                <p className="text-gray-600">{project.category}</p>
              </div>
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="text-gray-500 hover:text-gray-700"
              >
                {isExpanded ? (
                  <ChevronUp className="h-6 w-6" />
                ) : (
                  <ChevronDown className="h-6 w-6" />
                )}
              </button>
            </div>

            <p className="text-gray-700 mb-4">{project.description}</p>

            {isExpanded && (
              <div className="space-y-4 border-t pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-600">Location</p>
                    <p className="font-medium">{project.location}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Completion</p>
                    <p className="font-medium">{project.completion}</p>
                  </div>
                </div>
                
                <div>
                  <p className="text-gray-600 mb-2">Project Details</p>
                  <ul className="list-disc list-inside space-y-1">
                    {project.details.map((detail, index) => (
                      <li key={index} className="text-gray-700">{detail}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }
