import React, { useState, useEffect, useRef } from 'react';
    import { ChevronLeft, ChevronRight } from 'lucide-react';

    interface ProjectSliderProps {
      images: string[];
      title: string;
    }

    export default function ProjectSlider({ images, title }: ProjectSliderProps) {
      const [currentIndex, setCurrentIndex] = useState(0);
      const timerRef = useRef<number | null>(null);

      const nextSlide = () => {
        setCurrentIndex((prev) => (prev + 1) % images.length);
      };

      const prevSlide = () => {
        setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
      };

      useEffect(() => {
        timerRef.current = setInterval(nextSlide, 5000); // Change slide every 5 seconds

        return () => {
          if (timerRef.current) {
            clearInterval(timerRef.current);
          }
        };
      }, [images.length]);

      return (
        <div className="relative group">
          <div className="relative overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`${title} - Image ${index + 1}`}
                  className="w-full h-[400px] object-cover rounded-lg flex-shrink-0"
                  loading="lazy"
                />
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ChevronRight className="h-6 w-6" />
          </button>

          {/* Image Indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>
      );
    }
