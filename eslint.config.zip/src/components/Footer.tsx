import React from 'react';
    import { Instagram, Mail, Phone, Globe } from 'lucide-react';

    export default function Footer() {
      // Function to handle smooth scrolling
      const scrollToSection = (id: string) => {
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      };

      return (
        <footer className="bg-gray-900 text-white">
          <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
            {/* Footer Grid Layout */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Company Info */}
              <div>
                <h3 className="text-xl font-bold mb-4">CURVED CONCRETE</h3>
                <p className="text-gray-400">A multi-functional firm by Kamla Corporation</p>
              </div>

              {/* Contact Information */}
              <div>
                <h3 className="text-xl font-bold mb-4">Contact Us</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 mr-2" />
                    <a href="mailto:Uditmuniinfrawork21@gmail.com" className="text-gray-400 hover:text-white">
                      Uditmuniinfrawork21@gmail.com
                    </a>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 mr-2" />
                    <a href="tel:95337557444" className="text-gray-400 hover:text-white">
                      +91 95337557444
                    </a>
                  </div>
                  <div className="flex items-center">
                    <Globe className="h-5 w-5 mr-2" />
                    <a href="https://CURVEDCONCRETE.COM" className="text-gray-400 hover:text-white">
                      CURVEDCONCRETE.COM
                    </a>
                  </div>
                  <div className="flex items-center">
                    <Instagram className="h-5 w-5 mr-2" />
                    <a href="https://instagram.com/CURVED_CONCRETE22" className="text-gray-400 hover:text-white">
                      @CURVED_CONCRETE22
                    </a>
                  </div>
                </div>
              </div>

              {/* Quick Links */}
              <div>
                <h3 className="text-xl font-bold mb-4">Quick Links</h3>
                <ul className="space-y-2">
                  <li>
                    <button
                      onClick={() => scrollToSection('home')}
                      className="text-gray-400 hover:text-white"
                    >
                      Home
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => scrollToSection('about')}
                      className="text-gray-400 hover:text-white"
                    >
                      About Us
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => scrollToSection('services')}
                      className="text-gray-400 hover:text-white"
                    >
                      Our Services
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => scrollToSection('portfolio')}
                      className="text-gray-400 hover:text-white"
                    >
                      Portfolio
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => scrollToSection('contact')}
                      className="text-gray-400 hover:text-white"
                    >
                      Contact
                    </button>
                  </li>
                </ul>
              </div>
            </div>

            {/* Copyright Notice */}
            <div className="mt-8 pt-8 border-t border-gray-800 text-center">
              <p className="text-gray-400">&copy; {new Date().getFullYear()} CURVED CONCRETE. All rights reserved.</p>
              <p className="text-gray-500 mt-2">
                Developed and managed by <a href="https://github.com/hirenkothiya" className="text-gray-400 hover:text-white">Hiren Kothiya</a>
              </p>
            </div>
          </div>
        </footer>
      );
    }
