import React from 'react';
    import Navbar from './components/Navbar';
    import Footer from './components/Footer';
    import Home from './pages/Home';
    import About from './pages/About';
    import Services from './pages/Services';
    import Contact from './pages/Contact';
    import Portfolio from './components/Portfolio/index';

    function App() {
      return (
        <div className="bg-transparent fade-in flex flex-col min-h-screen">
          <Navbar />
          <div className="flex-grow">
            <div id="home"><Home /></div>
            <div id="about"><About /></div>
            <div id="services"><Services /></div>
            <div id="portfolio"><Portfolio /></div>
            <div id="contact"><Contact /></div>
          </div>
          <Footer />
        </div>
      );
    }

    export default App;
